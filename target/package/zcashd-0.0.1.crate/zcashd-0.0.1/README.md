# `zcashd`

## Getting started
```sh
cargo install zcashd
monerod
```

or use the library as in:
```rust
cargo add zcashd
```
